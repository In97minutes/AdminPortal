package com.adminportal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;



@SpringBootApplication
public class AdminportalApplication {
	
	public static void main(String[] args) {
		SpringApplication.run(AdminportalApplication.class, args);
	}
	
}
