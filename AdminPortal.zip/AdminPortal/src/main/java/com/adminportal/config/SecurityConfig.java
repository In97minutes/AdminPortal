package com.adminportal.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;


@Configuration
@EnableWebSecurity
//@EnableGlobalMethodSecurity(prePostEnabled=true)
public class SecurityConfig extends WebSecurityConfigurerAdapter {
	

	/*private static final String[] PUBLIC_MATCHERS = {
			"/css/**",
			"/js/**",
			"/image/**",
			"/newUser",
			
			"/",
			"/home",
			"/patient",
			"/patient/add",
			"/patient/patientList",
			"/patient/patientInfo",
			"/patient/updatePatient",
			"/patient/remove",
			"/patient/removeList",
			
			"/fonts/**"
			
	};

	@Override
	protected void configure(HttpSecurity http) throws Exception {
		http
			.authorizeRequests().
		
			antMatchers(PUBLIC_MATCHERS).
			permitAll().anyRequest().authenticated();

		 
	}*/
	
	
	
	
	/*@Configuration
	@EnableWebSecurity
	public class SecurityConfig extends WebSecurityConfigurerAdapter {*/

		//private static final Logger LOG = Logger.getLogger(SecurityConfig.class);
		
		
		@Value("${service.name}")
		private String serviceName;
		@Value("${admin.username}")
		public String hmsusername;

	   @Value("${admin.password}")
		public String hmspassword;
		//="cspuser";

		// Authentication : User --> Roles
		protected void configure(AuthenticationManagerBuilder auth) throws Exception {
			auth.inMemoryAuthentication().withUser(hmsusername).password(hmspassword).roles("USER");

		}

		// Authorization : Role -> Access
		protected void configure(HttpSecurity http) throws Exception {

			http.authorizeRequests().antMatchers("/" + serviceName + "/adminportal/**").hasRole("USER").anyRequest()
					.fullyAuthenticated();
			http.httpBasic();
			http.csrf().disable();

			/*http.authorizeRequests().antMatchers("/" + serviceName + "/CDCService/**").hasRole("USER").anyRequest()
			.fullyAuthenticated();
	http.httpBasic();
	http.csrf().disable();*/

		
		}

	}
	
            
           


